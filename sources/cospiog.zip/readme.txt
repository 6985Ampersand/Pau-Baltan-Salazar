Creative greetings...

Introducing Cospiog which has an elegant looking design. This font has additional ligatures to give it a varied appearance. You can use Cospiog in modern and contemporary designs, and is suitable for use in various fashion media, posters, modeling magazines, typography, promotions and other digital media.

FEATURES;

    Uppercase.
    Foreign Support, Numbers and Punctuation.
    Ligatures.
    Regular & Italic.
    Include Otf, ttf & Woff Files.
    Works on PC and Mobile.
    Simple installation.
    Accessible in Adobe Illustrator, Adobe Photoshop. Adobe InDesign, even works in Microsoft Word.
    Fully accessible without additional design software.

Cospiog is encoded with Unicode PUA, which allows full access to all additional characters without having to design any special software. Mac users can use the Font book, and Windows users can use the Character map to view and copy any additional characters to paste into your favorite text editor/app.

Thank you for visiting, have a nice day ;)

https://creativemarket.com/FigihRyanf
https://www.myfonts.com/collections/ryan-creative-foundry